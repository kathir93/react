const initState ={};

const authReducer = (state = initState, action) => {
    switch(action.type) {
        case 'CREATE_USER': 
         return {
             state : 
             action.user
             }
        case 'LOGIN':
         return state;
        default:
         return state;       
    }
    return state;
}

export default authReducer;