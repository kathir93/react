const initState ={
    projects: [
        {id:1, title: 'first'},
        {id:2, title: 'second'}
    ]
};

const projectReducer = (state = initState, action) => {
    return state;
}

export default projectReducer;