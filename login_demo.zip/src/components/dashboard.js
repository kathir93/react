import React, { Component } from 'react';
import {connect} from 'react-redux';

class Dashboard extends Component {
    render() {
        console.log(this.props);
        return (
            <div>
                Dashbaord
            </div>    
        )
    }
}

const mapStateToprops = (state) => {
    return {
        project: state.project.projects
    }
}

export default connect(mapStateToprops)(Dashboard);
