export const REGISTER_USER = 'REGISTER_USER';

export const submitAction = (user) => {
    return {
      type: REGISTER_USER,
      user
    }
  };

export default submitAction;