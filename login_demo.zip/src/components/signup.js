import React, {Component} from 'react';
import {Form, Button} from 'react-bootstrap';
import submitAction from '../actions/submitActions';
import {connect} from 'react-redux';

class Signup extends Component {
    constructor(props) {
        super(props);
        this.state = {
            user: {
            firstname: "",
            lastname: "",
            email: "",
            password: ""
            }
        }
        this.onChange = this.onChange.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
    }

    onChange(e) {         
        const { name, value } = e.target;
        const { user } = this.state;
        this.setState({
            user: {
                ...user,
                [name]: value
            }
        });    
    }  

    onSubmit(e) {        
        e.preventDefault();
        const { user } = this.state;
        this.props.dispatch(submitAction(user));
        console.log(this.props);
    }        

    render(){
        return(
            <div className="container">
            <Form onSubmit={this.onSubmit}>
            <Form.Group controlId="formBasicEmail">
                <Form.Label>Username</Form.Label>
                <Form.Control type="text" placeholder="Enter Email" onChange={this.onChange} name="username"/>
            </Form.Group>        
            <Form.Group controlId="formFirstname">
                <Form.Label>Firstname</Form.Label>
                <Form.Control type="text" placeholder="Enter firstname" onChange={this.onChange} name="firstname"/>
            </Form.Group>
            <Form.Group controlId="formLastname">
                <Form.Label>Lastname</Form.Label>
                <Form.Control type="text" placeholder="Enter Lastname" onChange={this.onChange} name="lastname"/>
            </Form.Group> 
            <Form.Group controlId="formPassword">
                <Form.Label>Password</Form.Label>
                <Form.Control type="password" placeholder="Password" onChange={this.onChange} name="password"/>
            </Form.Group>   
            <Form.Control variant="primary" type="submit" value="Submit"/>       
            </Form>              
            </div>        
        )
    }    
}

const mapStateToProps = (state) => {
    return {
        userFields : state.authReducer
    }
}



export default connect(mapStateToProps)(Signup);