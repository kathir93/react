
import React, { Component }  from 'react';
import {Form, Button} from 'react-bootstrap';

class Login extends Component {
    constructor(props){
        super(props);
        this.state = {
            username:'',
            password:''
        }
        this.onSubmit = this.onSubmit.bind(this);
        this.onChange = this.onChange.bind(this);
    }

    onSubmit(e) {
        e.preventDefault();
        console.log('logged');

    }
    onChange(e) {
        this.setState({
            [e.target.name]: e.target.value
        });
        console.log(this.state);
    }
    render() {
    return (
        <div className="container">
        <Form onSubmit={this.onSubmit}>
        <Form.Group controlId="formBasicEmail">
            <Form.Label>Username</Form.Label>
            <Form.Control type="email" placeholder="Enter username" onChange={this.onChange} name="username"/>
        </Form.Group>
        <Form.Group controlId="formBasicPassword">
            <Form.Label>Password</Form.Label>
            <Form.Control type="password" placeholder="Password" onChange={this.onChange} name="password"/>
        </Form.Group>   
        <Form.Control variant="primary" type="submit" value="Submit"/>       
        </Form>              
        </div>
    )
  }
}
export default Login;